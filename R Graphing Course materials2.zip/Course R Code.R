##############################################################
##########  BASE PACKAGE PART 1 #######################   ##############################################################
#Pay attention to your working directory!
setwd("U:/R Course/Graphing Course/")
getwd()
#Generate random numbers to plot
set.seed(23)
x <- rnorm(100, mean=20, sd=3)
y <- (x^2 + runif(100)) + rnorm(100, mean=20, sd=15)

#Create a character column
group <- ifelse(x>20, "A", "B")

#Create a data frame 
df <- data.frame(x, y, group)
df

#Scatter plot
plot(x) #creates an index by object number

plot(x, y) 

#OR 
plot(y~x)

#histogram
hist(x)

#barplot
barplot(x) #not very meaningful

#Often use the barplot function with categorical data
#For example:

cat <- c(red=15, blue=10, green=22)
barplot(cat)

#boxplot
#default is the median as center line of box, whiskers are 1.5*IQR, 
#observations outside of that will be plotted as points


boxplot(x)

boxplot(x,y)

boxplot(df$x~df$group)

#to turn off outlier printing, specify outline=FALSE
boxplot(df$x~df$group, outline=FALSE)

#scatterplot matrix
pairs(df) #don't really want group in the scatterplot matrix

z <- cbind(x,y)
pairs(z)

#Displaying part of data using subset & points()
plot(x,y,type="n")
subA <- subset(df, group=="A")
points(subA$x, subA$y)

points(x[group=="B"], y[group=="B"])

#line graph
plot(x, type="l")

#points with line overlay
plot(x, type="o")

#Create a blank plot window
plot(x, type="n")

#histogram like
plot(x, type="h")

#Labelling points
#Text labels
?text( )�
plot(x, y, main="X vs. Y",�xlab="x", ylab="y", pch=18, col="blue")
text(x, y, group, cex=0.6,  pos=4, col="red")

plot(x, y, main="X vs. Y",�xlab="x", ylab="y", type="n")
text(x, y, group, pos=4)

plot(x[group=="A"], y[group=="A"], xlim=c(10,30), ylim=c(100,800), xlab="x", ylab="y", type="p",  col="red")
points(x[group=="B"], y[group=="B"],pch=18,col="blue")

#Editing Axes
#Axis labels

#If you want a blank axis label, 
#specify
#xlab=� �

#To change axes label color
#col.lab="color"

#Axis label size
#cex.lab=1.5

#Titles
#main="Graph Title Here"

#Title color
#col.main="purple"

#Title size
#cex.main=1.5

#Subtitle 
#sub="Subtitle here"

#Title Function
title(main="main title", sub="sub-title", cex.main=2, font.main=4, col.main="blue", 
cex.sub=0.75,  font.sub=3, col.sub="red")

#Editing Axes
#Setting axes limits
#xlim=c(xmin, xmax)
#ylim=c(ymin, ymax)

#Add minor tick marks
#minor.tick()

#General syntax
#axis(side=, labels=, pos=, lty=, col=, las=, tck=)

plot(x[group=="A"], y[group=="A"], axes=F, ylim=c(100,800), xlab="", ylab="", type="p",  col="red", main="", xlim=c(10,30))

points(x[group=="B"], y[group=="B"], pch=20, col="black")

#Add axes using axis()
#To plot no axes
#axes=FALSE  
plot(x,y,type="n",axes=FALSE)
axis(1) #x-axis
axis(2) #y-axis
axis(3) # top axis
axis(4, col="blue", lwd=2) #right axis

#Change axis label orientation using las
#Default - Parallel to axis: las=0 
#For all labels horizaontal: las=1

plot(x,y,las=0)#default
plot(x,y,las=1) #all horizontal
plot(x,y,las=2) #y-axis horizontal, x-axis vertical
plot(x,y,las=3) #all vertical

#Copying & saving images
#Use the GUI to point & click (make sure plotting window is selected:
#File>>Save As>> and choose file type

#OR use function in R, such as pdf()
#If using pdf(), must close with dev.off()
#Allows you to specify any format and specify image dimensions, resolution, etc.

#Example with pdf()
pdf(file="file.pdf", width=10, height=7.5, #width & height of output in inches; default = 7
bg="white") #background color; default = "transparent"
plot(x[group=="A"], y[group=="A"], xlim=c(10,30), ylim=c(100,800), xlab="x", ylab="y", type="p",  col="red")
points(x[group=="B"], y[group=="B"],pch=18,col="blue")
dev.off()

#Active plotting window will not show your figure, 
#image will be saved to pdf in your working directory

###Exercise 1###
data<-read.csv("growth.csv",header=T)
head(data)
tail(data)
plot(data$length~data$age)
boxplot(data$length~data$year)
Before_2008<-subset(data, year>="2008")
boxplot(Before_2008$length~Before_2008$year, xlab="Years", ylab="Lenght (mm)",
main="Swedish Fish Length (2006-2009)",cex.main=1.5)
Years<-c(2006:2009)
Age<-c(1:20)
MeanL<-tapply(data$length,list(data$age),mean)
SD<-tapply(data$length,list(data$age),sd)
UL<-MeanL+(1.96*SD)
LL<-MeanL-(1.96*SD)
plot(MeanL~Age, type="l", ylab="Mean Length (mm)", 
main="Average Swedish Fish Length (2006-2009)", ylim=c(200,650))
lines(UL~Age,type="l",lty=2)
lines(LL~Age,type="l",lty=2)

##############################################################
##########  BASE PACKAGE PART 2 #######################   ##############################################################

x=seq(-1, 1, 0.01)
y=x^2

##RENEE'S DATA
# set.seed(23)
# x <- rnorm(100, mean=20, sd=3)
# y <- (x^2 + runif(100)) + rnorm(100, mean=20, sd=15)
#Create a character column
# group <- ifelse (x>20, "A", "B")
#Create a data frame 
# df<-data.frame(x,y,group)
#-----------------


##Plot windows
windows(18,6)
par(mar=c(1,1,3,1))
plot(y~x, type='l', ann=FALSE, xaxt='n', yaxt='n', lwd=2)
mtext(side=3, 'windows(18, 6)', cex=1.5, line=1)
box('figure')


##Plot windows
windows(6,10)
par(mar=c(1,1,3,1))
plot(y~x, type='l', ann=FALSE, xaxt='n', yaxt='n', lwd=2)
mtext(side=3, 'windows(6, 10)', cex=2, line=1)
box('figure')

##fig() argument
par(fig=c(0, 0.75, 0, 0.75), mar=c(0.4,0.4,4,0.4))
plot(y~x, type='l', ann=FALSE, xaxt='n', yaxt='n', lwd=2)
title(list('fig=c(0, 0.75, 0, 0.75)'), outer=TRUE, line=-3.25)


par(fig=c(0, 0.75, 0, 0.75), mar=c(0.4,0.4,4,0.4))
plot(y~x, type='l', ann=FALSE, xaxt='n', yaxt='n', lwd=2)
title(list('fig=c(0.25, 1, 0.25, 1)'), outer=TRUE, line=-3.25)
par(fig=c(0.25, 1, 0.25, 1), new=TRUE)
hist(y, ann=FALSE, xaxt='n', yaxt='n', col='gray80')
box()


##mfrow vs mfcol
#mfrow
windows(5, 3)
par(mfrow=c(2,3), mar=c(1,1,1,1), oma=c(0,0,3,0))
for(i in 1:6){
  plot(x,y, ann=FALSE, xaxt='n', yaxt='n', type='l')
  text(0, 0.5, labels=i, cex=4)
}
mtext(side=3, 'mfrow=c(2, 3)', outer=TRUE, cex=1.5)

#mfcol
windows(3, 3)
par(mfcol=c(2,2), mar=c(1,1,1,1), oma=c(0,0,3,0))
for(i in 1:4){
  plot(x,y, ann=FALSE, xaxt='n', yaxt='n', type='l')
  text(0, 0.5, labels=i, cex=4)
}
mtext(side=3, 'mfcol=c(2, 2)', outer=TRUE, cex=1.5)


#Mixed figure sizes
layout(matrix(1:4, nrow=2))
for(i in 1:4) plot(x)

ly <- layout(matrix(c(1,2,3,3), nrow=2, byrow=TRUE))
layout.show(ly)
plot(x)
plot(x)
plot(y, type='l', col='red', lwd=3)



##the mar argument
windows(5,3)
par(mfrow=c(1,2))
par(mar=c(3, 3, 2, 1))
plot(y~x, type='l', ann=FALSE, xaxt='n', yaxt='n')
mtext(side=3, 'mar=c(3, 3, 2, 1)', cex=1.25, line=0.5)
box('figure')

# windows(5,3)
par(mar=c(4, 2, 2, 2))
x=seq(-1, 1, 0.01)
y=x^2
plot(y~x, type='l', ann=FALSE, xaxt='n', yaxt='n')
mtext(side=3, 'mar=c(4, 2, 2, 2)', cex=1.25, line=0.5)
box('figure')


##The oma argument
windows(5, 3)
par(mfrow=c(2,2), mar=c(0,0,0,0), oma=c(4,4,3,1))
for(i in 1:4)
  plot(y~x, type='l', ann=FALSE, xaxt='n', yaxt='n')
mtext(side=3, 'oma=c(4,4,3,1)', outer=TRUE, cex=1.5, line=1)

windows(5, 3)
par(mfrow=c(2,2), mar=c(0,0,0,0), oma=c(1,1,3,1))
for(i in 1:4)
  plot(y~x, type='l', ann=FALSE, xaxt='n', yaxt='n')
mtext(side=3, 'oma=c(1,1,3,1)', outer=TRUE, cex=1.5, line=1)


##mtext
windows(5, 3)
par(mfrow=c(2,2), mar=c(0,0,0,0), oma=c(4,1,3,1))
for(i in 1:4)
  plot(y~x, type='l', ann=FALSE, xaxt='n', yaxt='n')
mtext(side=3, 'outer=FALSE', outer=TRUE, cex=1.5, line=1)
mtext(text='X AXIS', side=1, line=1, outer=FALSE)

windows(5, 3)
par(mfrow=c(2,2), mar=c(0,0,0,0), oma=c(4,1,3,1))
for(i in 1:4)
  plot(y~x, type='l', ann=FALSE, xaxt='n', yaxt='n')
mtext(side=3, 'outer=TRUE', outer=TRUE, cex=1.5, line=1)
mtext(text='X AXIS', side=1, line=2, outer=TRUE, cex=1.5)


##Omitting Axes
windows()
par(mar=c(2,5,2,2))
plot(y~x, xaxt='n', type='l', ann=FALSE, lwd=3, las=1, cex.axis=2)

##Log axes
quantile((y+3)^10, probs=c(.25,.5,.75,1))
ats <- c(70000, 130000, 350000, 1000000)

windows(5, 3)
par(mar=c(2.5,3.5,3,1))
plot((y+3)^10~x, type='l', ann=FALSE, las=1, yaxt='n', cex.axis=0.75)
axis(2, at=ats, labels=format(ats, scientific=TRUE), las=1, cex.axis=0.75)
mtext(text='Real scale', side=3, line=1, cex=1.5)
box('figure')

windows(5, 3)
par(mar=c(2.5,3.5,3,1))
plot((y+3)^10~x, type='l', ann=FALSE, log='y', yaxt='n', cex.axis=0.75)
axis(2, at=ats, labels=format(ats, scientific=TRUE), las=1, cex.axis=0.75)
mtext(text='Log scale', side=3, line=1, cex=1.5)
box('figure')


##Axis()
windows(5, 3)
par(mfrow=c(2,2), mar=c(0,0,0,0), oma=c(3,1,3,1))
ats <- seq(-1, 1, 0.5)
for(i in 1:4){
  plot(y~x, type='l', ann=FALSE, xaxt='n', yaxt='n')
  if(i==3) axis(1, at=ats)
  if(i==4) axis(1, at=ats, labels=c(NA, ats[-1]))
}
mtext(side=3, 'axis(side = 1)', outer=TRUE, cex=1.5, line=1)

################
###Exercise 2###
################

lob <- read.csv('lob.csv', header=TRUE)

##Looking at the data
ag <- aggregate(MT ~ YEAR, data=lob, FUN=sum)
windows(15,7)
par(mar=c(5,5,1,1))
plot(log(MT) ~ YEAR, data=ag, type='l', xlab='Year', ylab='Total landings (MT x 1000)',  cex.lab=1.25, lwd=2, las=1)
box('figure')

##Exercise
#log-scale
yl <- c(1, max(lob$MT))
txt.cex <- 1.5
lyn <- '' #'x', 'y', ''
windows(10,5)
par(mfrow=c(2,2), mar=c(0,0,0,0), oma=c(6,6,2,2))
plot(MT ~ YEAR, data=subset(lob, STATE=='ME'), xaxt='n', type='l', ylim=yl, log=lyn)
text(2013, 15000, 'Maine', cex=txt.cex, pos=2)
plot(MT ~ YEAR, data=subset(lob, STATE=='MA'), xaxt='n', yaxt='n', type='l', ylim=yl, log=lyn)
text(2013, 15000, 'Massachusetts', cex=txt.cex, pos=2)
plot(MT ~ YEAR, data=subset(lob, STATE=='CT'), type='l', ylim=yl, log=lyn)
text(2013, 15000, 'Connecticut', cex=txt.cex, pos=2)
plot(MT ~ YEAR, data=subset(lob, STATE=='NY'), yaxt='n', type='l', ylim=yl, log=lyn)
text(2013, 15000, 'New York', cex=txt.cex, pos=2)

mtext(side=1, 'Year', line=4, cex=1.5, outer=TRUE)
mtext(side=2, 'Landings (MT)', line=3, cex=1.5, outer=TRUE)


#Give each plot it's own Y axis
lob$MT1000 <- lob$MT/1000

txt.cex <- 1.5
lyn <- '' #'x', 'y', ''
lwd <- 2

windows(10,5)
par(mfrow=c(2,2), mar=c(0,0,0,0), oma=c(6,6,2,4))
plot(MT1000 ~ YEAR, data=subset(lob, STATE=='ME'), xaxt='n', yaxt='n', type='l', log=lyn,  lwd=lwd)
  axis(side=2, las=1)
  text(1950, 50, 'Maine', cex=txt.cex, pos=4)
plot(MT1000 ~ YEAR, data=subset(lob, STATE=='MA'), xaxt='n', yaxt='n', type='l', log=lyn,  lwd=lwd)
  axis(side=4, las=1)
  text(1950, 7, 'Massachusetts', cex=txt.cex, pos=4)
plot(MT1000 ~ YEAR, data=subset(lob, STATE=='CT'), type='l', yaxt='n', log=lyn, lwd=lwd)
  axis(side=2, las=1)
  text(1950, 1.5, 'Connecticut', cex=txt.cex, pos=4)
plot(MT1000 ~ YEAR, data=subset(lob, STATE=='NY'), yaxt='n', type='l', log=lyn, lwd=lwd)
  axis(side=4, las=1)
  text(1950, 3.8, 'New York', cex=txt.cex, pos=4)

mtext(side=1, 'Year', line=4, cex=1.5, outer=TRUE)
mtext(side=2, 'Landings (MT x 1000)', line=3, cex=1.5, outer=TRUE)

##############################################################
##########  BASE PACKAGE PART 3 #######################   
##############################################################

#slide 2
plot(x,y,ylim=c(-200,1000),xlim=c(-5,30))
abline(h=0)
abline(v=0)

#Add regression line slide 3
plot(x,y)
reg=lm(y~x)
abline(reg)

#Add other lines slide 5
plot(x,y)
abline(a=0,b=25,lty=2,lwd=3,col='maroon')
abline(a=800,b=-20,lty=4,lwd=5,col='orange')

#Bad graph line 6
set.seed(23)
w <- rnorm(20, mean=19, sd=4)
z <- (-8*w + runif(20)) + rnorm(20, mean=600, sd=5)

plot(x,y)
lines(w,z,type='l')
#sort Data
df2 <- data.frame(w,z)
df2 <-df2[order(w),]
#ordered line slide 8
plot(x,y)
lines(df2$w,df2$z,type='l')

#show that points can draw a line and vise versa slide 12
plot(x,y)
points(df2$w,df2$z,type='l',lty=3,col='purple',lwd=4)
points(df2$w,df2$z,type='p',pch=15,col='blue',cex=2)

plot(x,y)
lines(df2$w,df2$z,type='l',lty=3,col='purple',lwd=4)
lines(df2$w,df2$z,type='p',pch=15,col='blue',cex=2)

#add in a curve slide 15
plot(x,y)
curve(x^2-3*x+100,from=12,to=28,lty=4,lwd=3,add=TRUE)
somefunc <-  function(x) 50*sin(x)+400
curve(somefunc,from=12,to=28,lty=4,lwd=3,add=TRUE,n=500)

#Add this later after text modifier slide
text(x=23.5,y=610,labels=expression(y = x^2 - 3*x+100),srt=45)
text(14,470,expression(50*sin(x)+400))

#Add this after Plot math slide
text(15,625,expression(integral(x^2+y^2*partialdiff*x~~partialdiff*y,-infinity,0)," \n This is ",  underline(random)," Text")),lheight=1.5)

text(15,625,expression(paste(integral(x^2+y^2*partialdiff*x~~partialdiff*y,-infinity,0)," \n This  is ", underline(random)," Text")),lheight=1.5,adj=c(.25,0.5))

text(15,625,expression(integral(x^2+y^2*partialdiff*x~~partialdiff*y,-infinity,0),paste(" \n This  is ", underline(random)," Text"))),lheight=1.5,adj=c(.25,0.5))

text(15,625,expression(atop(integral(x^2+y^2*partialdiff*x~~partialdiff*y,-infinity,0),paste ("This is ", underline(random)," Text"))),lheight=1.5,adj=c(.25,0.5))

text(15,625,expression(atop(integral(x^2+y^2*partialdiff*x~~partialdiff*y,-infinity,0),paste ("This is ", underline(random)," Text"))),lheight=1.5)

#add test outside of margin slide 21
par(mai=c(1.25,2.2,.2,.2))
plot(x,y)
abline(reg,lwd=3)
curve(somefunc,from=12,to=28,lty=4,lwd=3,add=TRUE,n=500)
mtext(list("random","word","placement"),side=1,at=c(14, 18, 25),line=4)
mtext(list("Example text"),side=2,at=c(400),line=5,adj=c(1),padj=c(0.5),las=3)

#Add legends
plot(x,y,pch=7,col="forestgreen",cex=1.75,lwd=2)
abline(reg,lwd=5,lty=6,col="royalblue")
curve(somefunc,from=12,to=28,lty=4,lwd=3,add=TRUE,n=500,col="red")
legend("topleft",expression("Data Points","Regression Line", y==50*sin(x)+200),col=c ("forestgreen","royalblue","red"),pch=c(7,NA,NA),lwd=c(NA,5,3),lty=c(0,6,4),pt.cex=c (1.75,0,0),pt.lwd=c(2,0,0), horiz=TRUE,title = "Legend Box Title", x.intersp = 0.5)

legend(13,625,expression("Data Points","Regression Line", y==50*sin(x)+200),col=c ("forestgreen","royalblue","red"),pch=c(7,NA,NA),lwd=c(NA,5,3),lty=c(0,6,4),pt.cex=c (1.75,0,0),pt.lwd=c(2,0,0),bty ="n", x.intersp=6, y.intersp=2.5,text.font=4 , seg.len=6)

legend("bottomright",inset=0.05,expression("Data Points","Regression Line", y==50*sin (x)+200),col=c("forestgreen","royalblue","red"),pch=c(7,NA,NA),lwd=c(NA,5,3),lty=c (0,6,4),pt.cex=c(1.75,0,0),pt.lwd=c(2,0,0),bg="orange",cex=1.25,text.col="maroon",title = "Legend  Box Title",title.col="blue",title.adj=0, ncol=2, box.lty=5, box.lwd=4,box.col="green")


#Drawing arrows slide 27
plot(x=NA,xlim=c(0,1),ylim=c(0,1),xlab="",ylab="",bg="transparent")
arrows(x0=c(0,0,.8,.1),y0=c(0,1,.25,.5),x1=c(1,1,.8,.66),y1=c (1,0,.75,0),length=.2,angle=40,code=2,lty=c(1,2,3,4),col=c(1,2,3,4), lwd=c(2,4,6,7))


plot(x=NA,xlim=c(0,1),ylim=c(0,1),xlab="",ylab="")
arrows(x0=c(0,0,.8,.66,1),y0=c(0,1,.25,0,0),x1=c(1,1,.8,.1,0),y1=c (1,0,.75,.5,1),length=.2,angle=40,code=2,lty=c(1,2,3,4,2),col=c(1,2,3,4,2), lwd=c(2,4,6,7,4))

#Drawing arrows with different arrowheads slide 28
plot(x=NA,xlim=c(0,1),ylim=c(0,1),xlab="",ylab="")
arrows(x0=c(0),y0=c(0),x1=c(1),y1=c(1),length=.2,angle=40,code=2,lty=c(1),col=c(1), lwd=c(2))
arrows(x0=c(0),y0=c(1),x1=c(1),y1=c(0),length=.8,angle=10,code=3,lty=c(2),col=c(2), lwd=c(4))
arrows(x0=c(.8),y0=c(.25),x1=c(.8),y1=c(.75),length=.3,angle=80,code=1,lty=c(3),col=c(3), lwd=c (6))
arrows(x0=c(.1),y0=c(.5),x1=c(.66),y1=c(0),length=.5,angle=25,code=2,lty=c(4),col=c(4), lwd=c(7))

#Excercise Code
png(file="exercise.tiff",width=7,height=7,res=300,unit="in",bg="transparent")
#left
#par(fig=c(x0,x1,y0,y1)
par(fig=c(0.1, 0.3, 0.7, 0.9), mar = c(0, 0, 0, 0))
#plot.new()
plot(x,y,col='orange',pch=25)

#Middle
par(fig = c(.4,.6,.7,.9) , mar = c(0,0,0,0),new=TRUE)
#plot.new()
plot(df2$w,df2$z,type='l',lty=3,col='purple',lwd=3)

#Right
par(fig = c(.7,.9,.7,.9),mar=c(0,0,0,0),new=TRUE)
plot(df2$w,df2$z,type='p',pch=15,col='blue',cex=1.1)

#Bottom
## par(fig = c(.15,.25,.4,.6), new = TRUE)
par(fig=c(0.2, 0.8,.15,0.45),mar=c(0,0,0,0),new=TRUE)
plot(x,y,col='orange',pch=25)
lines(df2$w,df2$z,type='p',pch=15,col='blue',cex=1.5)
lines(df2$w,df2$z,type='l',lty=3,col='purple',lwd=4)

legend('topleft',legend=c("Dataset 1","Dataset 2"),col=c('orange','blue'),pch=c(25,15),lty=c (0,0),lwd=c(1,4),pt.cex=c(1,1.5))
legend('topleft',legend=c("",""),col=c(NA,'purple'),lty=c(0,3),lwd=c(NA,4),bty='n')
mtext(text=expression(paste(integral()," These ",italic(three)," ", underline(plots)," ", bold (together))),side=1, line=3)

#Arrows
par(fig = c(0, 1, 0, 1), new = TRUE)
plot.new()

arrows(x0=.2,x1=.48,y0=.65,y1=.46,length=.2,angle=30,lwd=2,col='red')
arrows(x0=.5,x1=.5,y0=.65,y1=.46,length=.2,angle=30,lwd=2,col='blue',lty=4)
arrows(x0=.8,x1=.52,y0=.65,y1=.46,length=.2,angle=30,lwd=5,col='green',lty=2)
arrows(x0=c(.285,.615),x1=c(.33,.66),y0=c(.825,.825),y1=c (.825,.825),code=3,angle=40,length=.09,col='orange',lwd=3)

#Text for arrows
text((.2+.48)/2+.01,(.65+.46)/2+.01,labels="Combine",srt=-33) 
text(.51,(.65+.46)/2,labels="These 3", srt=90)
text((.8+.52)/2,(.65+.46)/2+.025,labels="Plots",srt=42)

#text for fig coordinates
text(.05,.64,labels="(0.1, 0.7)",pos=4)
text(.24,.95,labels="(0.3, 0.9)")
text(.56,.95,labels="(0.6, 0.9)")
text(.9,.64,labels="(0.9, 0.7)")
text(0.16,.47,labels="(0.2, 0.45)",pos=4)
text(0.83,.15,labels="(0.8,0.15)",adj=c(0,1))

dev.off()

#Text modifer example figure slide 17
   #cex multiplier
par(fig = c(0, 1, 0, 1), new = TRUE,mar=c(0,0,0,0),ps=16)
plot.new()
text(.2,.1,"Normal text")
text(.5,.1,"cex = 2", cex=2)
text(.7,.1,"cex = 0.5", cex=.5)

    #text justification
#text(.5,.2,"Default Center")
#text(.5,.25,"Left adj = 0",adj=0)
#text(.5,.3,"Right adj = 1",adj=1)
text(.5,.25,"adj=c(0,1)   ",adj=c(0,1))
text(.5,.25,"adj=c(0,0)   ",adj=c(0,0))
text(.5,.25,"  adj=c(1,1)",adj=c(1,1))
text(.5,.25,"  adj=c(1,0)",adj=c(1,0))
    #character rotate
text(.2,.37, expression(atop("string rotation",30*degree)), srt=30)
text(.8,.4, expression(paste("string rotation 180",degree)), srt=180)

    #family  sans serif mono  symbol
text(.2,.5,family='sans',"family = 'sans'")
text(.7,.5,family='serif',"family = 'serif'")
text(.2,.55,family='mono',"family = 'mono'")
text(.7,.55,family='symbol',"family = 'symbol'")

    #1 plain 2bold 3italic 4bold italic, 5 symbol
text(.2,.65,font=1,"font = 1")
text(.7,.65,font =2,"font = 2")
text(.2,.7,font=3,"font = 3")
text(.7,.7,font =4,"font = 4")
text(.5,.75,font=5, "font = 5")

#line height multiplier
text(.2,.85,"line height \n default")
par(lheight=2)
text(.5,.85,"lheight=2 \n double")
par(lheight = 0.5)
text(.9,.85,"lheight= 0.5 \n half")
text(.5,.95,"Need to set lheight in par but affects text and mtext")


#mathplot expression slide 18
plot(x=NULL, xlim=c(0,20),ylim=c(0,8),ylab="",xlab="")
text(10,7,expression(integral(f(x,y)*partialdiff*x*partialdiff*y,-infinity,0.5) ~~  ~~ sum(frac (1,1+x),i==1,n) ~~ ~~ prod(x[i],i==1,infinity) ~~ ~~ lim(over(1,f(x)),x%->%0 )))
text(10,6,expression(list(bold("bold"),italic("italic"), underline("underline"), bolditalic("bold  italic"))))
text(10,5,expression(paste("sub"["script"],~~ ~~"super"^"script", ~~ ~~sqrt(y,z), ~~ ~~x^(y+z),  ~~ ~~ x^{y+z})))
text(10,4,expression(list(alpha,"to",omega,Alpha,"to",Omega, hat(a),tilde(b),dot(c),ring(d),bar (e),widehat(fgh), widetilde(lmno))))
text(5,3,expression(paste(32*degree,58*minute,30*second )))
text(15,3,expression(paste(32*degree,~~ 58*minute, ~~30*second )))
text(10,2,expression(list(x+y,x-y,x%+-%y, x*y,x%*%y, x/y,x%/%y,x%.%ym, x==y, x!=y, x<y,x>y)))
text(10,1,expression(list(x<=y,x>=y,x %~~% y,x %=~% y,x %==% y,x %prop% y,x %~% y)))
#############################################################################################
#Generate random numbers to plot and load growth data
set.seed(23)
x <- rnorm(100, mean=20, sd=3)
y <- (x^2 + runif(100)) + rnorm(100, mean=20, sd=15)
#Create a character column
group <- ifelse (x>20, "A", "B")
#Create a data frame
df<-data.frame(x,y,group)
df
data<-read.csv("growth.csv",header=T)

##############################################################
##########  BASE PACKAGE PART 4: COLORS ######################   ##############################################################
colors()
palette()

#These all do the same thing
plot(x, y, col="red")
plot(x, y, col=2)
plot(x, y, col="#FF0000")

#To specify the color of an open point
plot(x, y, pch=21, col="red", bg="black", cex=2)

#Different points different colors
plot(x, y, pch=16, col=c(1:8), cex=2)
plot(x, y, pch=16, col=c("red", "blue", "green"), cex=2)

#Coloring lines
abline(mean(y), 0, lwd=2, col='purple')

#Changing the background
par(bg='white')
plot(x, y, pch=16, col=c("red", "blue", "green"), cex=2)

#Coloring groups of points
plot(df$x, df$y, pch=16, col=df$group)
plot(df$x, df$y, pch=16, col=c("green","red")[df$group])

plot(data$length, data$weight, pch=16, col=as.factor(data$year))
legend("topleft", legend=levels(as.factor(data$year)), col=c(1:length(levels(as.factor(data $year)))), pch=16)

#What if you hadn't specified year as a factor?
plot(data$length, data$weight, pch=16, col=data$year)

#R pre-created color palettes
#rainbow(); heat.colors(); terrain.colors(); topo.colors(); cm.colors() are a few of your options
plot(x, y, pch=16, col=rainbow(20)) #Simply specify the amount of colors you want from that  palette

#Creating your own palettes
palette(c("red", "green", "purple"))
plot(df$x, df$y, pch=16, col=df$group)

heat.palette <- heat.colors(length(df$x))
palette(heat.palette)
plot(df$x, df$y, pch=16, col=rank(-df$x))

heat.palette <- heat.colors(length(df$x)+10)
palette(heat.palette)
plot(df$x, df$y, pch=16, col=rank(-df$x))

#Using colorRampPalette
Lisa.palette <- colorRampPalette(c("yellow","purple"))
palette(Lisa.palette(20))
plot(data$length, data$weight, pch=16, col=as.factor(data$age))

palette("default")
plot(data$length, data$weight, pch=16, col=as.factor(data$age))

#Grayscale
gray.palette <- gray(20:0/20)
palette(gray.palette)
plot(data$length, data$weight, pch=16, col=as.factor(data$age))

####R Color Brewer#########
#install.packages("RColorBrewer") #Only need to do this once
library(RColorBrewer)
display.brewer.all()

my.col=brewer.pal(9, "Set1")
boxplot(data$length~data$age, col=my.col)

my.col=brewer.pal(4, "PuBu")
palette(my.col)
plot(data$length, data$weight, pch=16, col=as.factor(data$year))
my.col=brewer.pal(20, "PuBu") #Error message

####RColorBrewer + colorRampPalette#######
my.col=brewer.pal(9, "BuPu")
pal=colorRampPalette(my.col)
palette(pal(20))
plot(data$length, data$weight, pch=16, col=as.factor(data$age))

#You can even do all this in one line of code
plot(data$length, data$weight, pch=16,col=colorRampPalette(brewer.pal(9, "BuPu"))(20)[as.factor (data$age)])

palette("default")

##### EXERCISE 4 ######
#Part 1
load("number_of_detections_byfish.RData")
dat<-number_of_detections_byfish
head(dat)
palette("default")

dat.mean<-mean(dat$detections)
dat.sd<-sd(dat$detections)
dat.mean-dat.sd
dat.mean+(1.96*dat.sd)

par(bg="lightgrey")
plot(dat$fish_id,dat$detections)
dat$col.grp<-ifelse(dat$detections<=dat.mean+(1.96*dat.sd),"A","B")
plot(dat$fish_id,dat$detections,col=as.factor(dat$col.grp),pch=16, xlab="Fish ID", ylab = "Number  of Detections", main = "Number of Detections by Fish", col.main="darkblue")
abline(h=dat.mean+(1.96*dat.sd), col="red", lty=2)
abline(h=dat.mean, lwd=2, col="darkblue")
text(x=300,y=dat.mean+5000, paste("Mean = ", round(dat.mean)), col="Dark Blue")

#Part 2
windows()
length(unique(dat$date_released))
my.col<-brewer.pal(9, "Set1")
pal <- colorRampPalette(my.col)
palette(pal(20))
plot(dat$fish_id,dat$detections,ylim=c(0,165000),col=as.factor(dat$date_released),pch=16,  xlab="Fish ID", ylab = "Number of Detections", main = "Number of Detections by Fish", xlim=c (0,1300))
legend("topright", legend=levels(as.factor(dat$date_released)), col=1:20, pch=16)

#Part 3
load("C:\\Users\\peter710\\Desktop\\Desktop - April 2015\\Telemetry Data\\stat_info.RData")
dat2<-stat_info
my.col<-brewer.pal(9, "YlOrRd")
pal <- colorRampPalette(my.col)
palette(pal(length(dat2$Lat)))
plot(dat2$Long,dat2$Lat, pch=16, col = as.factor(dat2$num_detec), ylab="Latitude",  xlab="Longitude")
title("Detections per Receiver in Lake Erie")

#Another way
dat2$col.grp <- ifelse(dat2$num_detec >=100000, "A", ifelse(dat2$num_detec <=500, "C", "B"))
summary(dat2)
my.col<-brewer.pal(3, "YlOrRd")
palette(my.col[3:1])
plot(dat2$Long, dat2$Lat, pch=16, col = as.factor(dat2$col.grp), ylab="Latitude",  xlab="Longitude")
legend("bottomright", legend = c(">100000","500-100000","0-500"), col = 1:3, pch=16)
title("Detections per Receiver in Lake Erie")

##############################################################
##########  GGPLOT2#######################   ##############################################################

###########################
#####data read-in###########
###########################
library('plyr') #data manipulation
library('ggplot2') #graphing

#read in csv file
dat<-read.csv("growth.csv")
#check the structure of data frame 'dat'
str(dat)
#convert numeric variables 'age' and 'year' as factor
dat$age<-as.factor(dat$age)
dat$year <- as.factor(dat$year)

###########################
####data and mapping#######
###########################

p_lw <- ggplot(data=dat, mapping=aes(x=length, y=weight))
summary(p_lw)

p_lw + layer(geom="blank")

###########################
#########  geom  ##########
###########################
p_lw <- ggplot(data=dat, mapping=aes(x=length, y=weight))
p_lw + geom_blank()
p_lw + geom_point()
p_lw + geom_line()

ggplot(dat, aes(length))+ geom_histogram() + #geom_histogram(binwidth = 10)
ggplot(dat, aes(length))+ geom_density()

#calculate the mean and sd for each level of age, save results as new data frame mm
mm<-ddply(dat,'age',summarise,mu=mean(length),sd=sd(length))
mm
ggplot(mm, aes(x=age,y=mu))+ geom_bar(stat = "identity")

ggplot(mm, aes(x=age,y=mu))+ geom_bar(stat = "identity")+ geom_errorbar(aes(ymin=mu-2*sd,  
ymax=mu+2*sd), colour="red")+ylab('length')

p_lw + geom_point()+geom_smooth(method="loess")
p_lw + geom_point()+geom_smooth(method="lm")
p_lw + geom_point()+geom_smooth(method="lm",se=F)

###exercise 1
p_al <- ggplot(data=dat,mapping=aes(x=age,y=length))
# p_al+layer(geom="boxplot")
p_al <- p_al+geom_boxplot()
p_al

###########################
#########  stat  ##########
###########################

ggplot(dat, aes(age, length))+
stat_summary(fun.y = mean, geom = "bar")

#plus or minus 2 standard deviations
ggplot(dat, aes(age, length))+
  stat_summary(fun.y = mean, geom = "point")+
stat_summary(fun.data = mean_sdl, geom = "errorbar",colour='red')

library('Hmisc')
?smean.sdl

#####exercise 2
#the lower and upper quantiles computed are 0.025 and 0.975
ggplot(dat, aes(age, length))+
 # geom_boxplot()
   stat_summary(fun.y = median, geom = "bar")+
   stat_summary(fun.data = median_hilow, geom = "errorbar",colour='red')#+
   #geom_boxplot()
   
 
#calculate the mean and sd for each level of age, save results as new data frame mm
mm<-ddply(dat,'age',summarise,mu=median(length),up=quantile(length,0.975),low=quantile (length,0.025))
mm
ggplot(mm, aes(x=age,y=mu))+ geom_bar(stat = "identity")
ggplot(mm, aes(x=age,y=mu))+ geom_bar(stat = "identity")+ geom_errorbar(aes(ymin=low, ymax=up),  colour="red")+ylab('length')

 
###########################
#######  aes ##############
###########################

ggplot(dat, aes(length, weight))+
   geom_point(aes(shape=stock,color=year,alpha=0.2))+
   stat_smooth(aes(linetype=stock),method="loess",se=F)

ggplot(dat, aes(length, weight))+
  geom_point(aes(shape=stock,color= year))+
  stat_smooth(aes(linetype=stock),method="loess", se=F)

p_al<-ggplot(dat, aes(length,fill=stock))

p_al+�geom_bar(position="stack")
p_al+�geom_bar(position="dodge")
p_al+�geom_bar(position="fill")

###########################
###### scale ##############
###########################

p_al + geom_bar(color="black",position="dodge") + 
scale_fill_grey() 
library(RColorBrewer)
p_al + geom_bar(position="dodge") + 
scale_fill_manual(values=brewer.pal(3,"Greys"),name='Population',labels=c('central','South'))

###########################
####### facet #############
###########################

###But sometimes they are not clear enough, facet
ggplot(dat, aes(length, weight,color= factor(stock))) +
geom_point() +
facet_wrap(~ year, nrow=4)

g <- ggplot(dat, aes(length, weight)) + geom_point() + facet_grid(stock~ year)
g

ggsave("F1.eps", plot = g,  width=8, height= 3.2) 

###########################
####### labels ############
###########################

g <- g+xlab('Total length') +ylab('Weight') +ggtitle ('length weight relationship for lake  whitefish populations in Lake Michigan')
ggsave("F1.eps", plot = g,  width=8, height= 3.2) 
g

###########################
######## theme ############
###########################

p_lw<-ggplot(data=dat,mapping=aes(x=length,y=weight,color=stock))
p_lw+geom_point()+theme_gray()
p_lw+geom_point()+theme_bw()
p_lw+geom_point()+theme_classic()

ggplot(dat, aes(age, length,color=stock))+geom_boxplot()+xlab('Age')+ylab('Length(mm)')+theme_bw () +theme(legend.position='bottom') 

###########################
######## save #############
###########################

ggsave("F1.jpg", plot = g,  width=7, height=6)   
ggsave("F1.eps", plot = g,  width=7, height=6) 
# getwd()

#####exercise 3

p_tmp<-ggplot(dat, aes(age, length,fill= factor(stock))) +
geom_boxplot(position='dodge') +
facet_wrap(~ year)
p_tmp

##############################################################
##########GRAPHING SPATIAL DATA#######################   ##############################################################
####### Introduction to graphing spatial data (need to have ggplot2 already active)
library(rgdal)
library(sp)
library(maptools)
library(maps)
library(ggmap)

load("stat_info.RData")
setwd("U:/R Course/Graphing Course/Spatial/")
#Google maps in R (requires ggmap)
qmap("Lansing")
qmap("48073")
qmap("Michigan")
qmap("Michigan", zoom=6)
qmap("Lansing", zoom=16, maptype='satellite')
qmap("Michigan State University", zoom=15, maptype="watercolor")
#One issue with this is that it is not simple overlaying points
qmap("Lake Erie", zoom=7)
points(stat_info$Long, stat_info$Lat, pch=16, col="red") #This doesn't work

LE_gg <- qmap("Lake Erie", zoom=7)
LE_gg + geom_point(data = stat_info, aes(x = Long, y = Lat), color="red", size=3, alpha=0.5)

Sand_gg <- qmap("Sandusky", zoom=9)
Sand_gg + geom_point(data = stat_info, aes(x = Long, y = Lat), color="red", size=3, alpha=0.5)

#Pre-loaded maps in the maps package
map("state", "michigan:south", fill=T, col=2)
map("state", interior = FALSE, col="blue")
map("state", boundary = FALSE, lty = 2, add = TRUE, col="dark blue")
title("United States of America")

map("state", region = c("michigan", "ohio", "pennsylvania", "new york"))
points(stat_info$Long,stat_info$Lat, pch=16)
map.axes()


map("state", xlim=range(stat_info$Long), ylim=range(stat_info$Lat))
points(stat_info$Long,stat_info$Lat, pch=16) 
#Kinda weird looking without the Lake Erie boundary, so we can go out to the internet to find a  shape file

#Using rgdal to read in shape files
Lake_Erie <- readOGR(dsn=".", layer="Lake_Erie_Shoreline")
plot(Lake_Erie)
summary(Lake_Erie) #Already in the longlat coordinate system, so we could plot points directly on  it
points(stat_info$Long,stat_info$Lat, pch=16, col="red")

map("state", xlim=range(stat_info$Long), ylim=range(stat_info$Lat))
plot(Lake_Erie, add=T)
points(stat_info$Long,stat_info$Lat, pch=16) 

class(Lake_Erie)
slotNames(Lake_Erie)
names(Lake_Erie)

Lake_Erie_bath <- readOGR(dsn=".", layer="Lake_Erie_Bathymetric_Contours")
plot(Lake_Erie_bath, col="blue")
points(stat_info$Long,stat_info$Lat, pch=16)

class(Lake_Erie_bath)
slotNames(Lake_Erie_bath)
head(Lake_Erie_bath@data)

#What if you want to look at the deepest area of Lake Erie?
maxDepth <- max(Lake_Erie_bath$DEPTH_M)
deepestMask <- which(Lake_Erie_bath$DEPTH_M == maxDepth)
deepestArea <- Lake_Erie_bath[deepestMask,]
lines(deepestArea, col="red")

plot(deepestArea, col="red", axes=T)
plot(Lake_Erie_bath, add=T, col=c("lightblue"))
plot(deepestArea, col="darkblue", add=T, lwd=2)
title("Deepest Part of Lake Erie")
points(stat_info$Long,stat_info$Lat, pch=16, cex=2)

#Quickly making spatial graphs with a z variable using spplot
spplot(Lake_Erie_bath, zcol="DEPTH_M")
spplot(Lake_Erie_bath, zcol="DEPTH_M", col.regions=topo.colors(20))
spplot(Lake_Erie_bath, zcol="DEPTH_M", col.regions=colorRampPalette(brewer.pal(9, "BuPu"))(20))
plot.col <- colorRampPalette(brewer.pal(9, "BuPu"))(23)
plot.col <- plot.col[23:4]
spplot(Lake_Erie_bath, zcol="DEPTH_M", col.regions=plot.col)
title("Lake Erie Depth(m)")


#Bonus fun with google maps!
qmap("Natural Resources Building, Michigan, USA", zoom=15)
from <- "Giltner Hall, Michigan, USA"
to <- "MSU Union, Michigan, USA"
route_df <- route(from, to, structure = 'route', mode = 'driving')
qmap("Giltner Hall, Michigan, USA", zoom = 15) +
  geom_path(aes(x=lon, y=lat),  colour='red', size=1.5, data=route_df, lineend='round')
